Exploratory Analysis of NYPD Traffic collision:

This project is aimed at analyzing past 3 years traffic collision data given by New York traffic police department(NYPD) to uncover the hidden insights and provide viable suggestions substantiated by the proper numbers which would aid NYPD in taking mission critical decisions. Dissection of this data includes descriptive statistics of the data, visual representations of key attributes, charts for comparing and understanding the summary of data. 

Data Source: https://data.ny.gov/Public-Safety/NYPD-Motor-Vehicle-Collisions/h9gi-nx95
